﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Webbanmaytinh
{
    public class Product
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string Images { get; set; }
        public string Detail { get; set; }
    }
}