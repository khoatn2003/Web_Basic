﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Webbanmaytinh
{
    public partial class Dangnhap : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                string usernameL = Request.Form.Get("usernameL");
                string passwordL = Request.Form.Get("passwordL");
                int dem = 0;
                if (usernameL != "" && passwordL != "")
                {
                    List<Nguoidung> users = (List<Nguoidung>)Application["Users"];

                    foreach (Nguoidung user in users)
                    {
                        if (usernameL == user.username)
                        {
                            dem = 1;
                            if (passwordL == user.password)
                            {
                                Session["username"] = usernameL;

                                // Kiểm tra và chuyển hướng đến ReturnUrl nếu có
                                string returnUrl = Session["ReturnUrl"] as string;
                                if (!string.IsNullOrEmpty(returnUrl))
                                {
                                    Response.Redirect(returnUrl);
                                }
                                else
                                {
                                    Response.Redirect("Acer.aspx"); // Chuyển đến trang mặc định nếu không có ReturnUrl
                                }
                                break;
                            }
                            else
                            {
                                errorL.InnerHtml = "Sai mật khẩu";
                                break;
                            }
                        }
                    }
                    if (dem == 0)
                    {
                        errorL.InnerHtml = "Không tồn tại tài khoản ";
                    }
                }
            }
        }
    }
}
