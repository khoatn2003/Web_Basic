﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Webbanmaytinh
{
    public partial class Dangky : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
  
            if (IsPostBack)
            {
                string username = Request.Form.Get("username");
                string email = Request.Form.Get("email");
                string password = Request.Form.Get("password");
                string repassword = Request.Form.Get("re-password");
                List<Nguoidung> users = (List<Nguoidung>)Application["Users"];
                bool check = true;
                if (username != "" && email != "" && password != "" && repassword != "")
                {

                    if (!IsValidEmail(email))
                    {
                        btn_error.InnerHtml = "Email không đúng định dạng";
                        check = false;
                    }

                    if (password != repassword)
                    {
                        btn_error.InnerHtml = "Mật khẩu nhập lại không khớp";
                        check = false;
                    }

                    foreach (Nguoidung user in users)
                    {
                        if (username == user.username)
                        {
                            btn_error.InnerHtml = "Tài khoản đã được sử dụng";
                            check = false;
                        }
                    }

                    if (check)
                    {
                        btn_error.InnerHtml = "Đăng ký thành công";
                        Nguoidung newUser = new Nguoidung(username, email, password, repassword);
                        users.Add(newUser);
                        Application["Users"] = users;
          
                    }
                   
                }
            }
        }
        private bool IsValidEmail(string email)
        {
            string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(email, emailPattern);
        }
    }
}